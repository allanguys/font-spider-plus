{


    "localPath" : "../font/",

    "onlinePath" : "../font/",

    "url" :  ["http://fn.qq.com/web201803/main.shtml","http://fn.qq.com/web201803/video_list.shtml","http://fn.qq.com/webplat/info/news_version3/10021/34544/m20247/list_1.shtml"
    ,"http://fn.qq.com/webplat/info/news_version3/10021/34544/34546/m20281/201803/699393.shtml"
,"http://fn.qq.com/web201803/video_list.shtml"]
}